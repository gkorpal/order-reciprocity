# This code was generated with the help of Microsoft Copilot

import os
import pandas as pd
from collections import defaultdict

# Directory where the CSV files are stored
directory = os.getcwd()

# Initialize a dictionary to store the results
results = defaultdict(list)

# Initialize a set to store the existing CSV file names
existing_files = set()

# Loop through all the files in the directory
for filename in os.listdir(directory):
    # Check if the file is a CSV file
    if filename.endswith('.csv'):
        # Construct the full file path
        file_path = os.path.join(directory, filename)
        
        # Load the CSV file into a DataFrame
        df = pd.read_csv(file_path, header=None)
        
        # Get the number of entries in the CSV file
        num_entries = len(df)
        
        # Remove ".csv" from the filename
        filename_without_csv = filename.replace('.csv', '')
        
        # Append the filename to the corresponding number of entries in the results dictionary
        results[num_entries].append(filename_without_csv)
        
        # Add the filename to the set of existing files
        existing_files.add(filename_without_csv)

# Convert the results dictionary into a list of tuples, each containing the number of entries, the list of file names, and the number of file names
results_list = [(k, v, len(v)) for k, v in results.items()]

# Check for missing k-kk.csv files
missing_files = []
for k in range(2, 52):
    for kk in range(k, 52):
        file_name = f"{k}-{kk}"
        if file_name not in existing_files:
            missing_files.append(file_name)
            # Add the missing file to the results with 0 entries
            results[0].append(file_name)

# Convert the results dictionary into a list of tuples, each containing the number of entries, the list of file names, and the number of file names
results_list = [(k, v, len(v)) for k, v in results.items()]

# Convert the results list into a DataFrame
results_df = pd.DataFrame(results_list, columns=['Number of Entries', 'File Names', 'Number of Files'])

# Sort the DataFrame by 'Number of Entries' in descending order
results_df = results_df.sort_values(by='Number of Entries', ascending=False)

# Save the results to a tex file
results_df.to_latex('frequency_table.tex', index=False)

# Print a success message
print("The results have been saved to 'frequency_table.tex'.")
